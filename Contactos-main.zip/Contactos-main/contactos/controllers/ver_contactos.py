import web
import sqlite3
render = web.template.render('views', base='layout')
class Ver_contactos():
    def buscarContacto(self, id_contacto:int):
        try:
            conexion = sqlite3.connect("sql/agenda.sqlite")
            conexion.row_factory = sqlite3.Row
            cursor = conexion.cursor()
            query = "SELECT * FROM contacto where id_contacto = ?;"
            cursor.execute(query,(id_contacto,))
            resultado = cursor.fetchone()

            contacto = {
                "id_contacto":resultado[0],
                "nombre":resultado[1],
                "primer_apellido":resultado[2],
                "segundo_apellido":resultado[3],
                "email":resultado[4],
                "telefono":resultado[5]
                }

            conexion.close()
            print(contacto)
            return contacto
        except sqlite3.Error as error:
            print(f"ERROR 102: {error.args}")
            return []
        except Exception as error:
            print(f"ERROR 103: {error.args}")
            return []

    def GET(self, id_contacto):
        print(f"id contacto: {id_contacto}")
        contacto=self.buscarContacto(id_contacto)
        id=contacto['id_contacto']
        name=contacto['nombre']
        f_lastname=contacto['primer_apellido']
        s_lastname=contacto['segundo_apellido']
        email=contacto['email']
        tel=contacto['telefono']
        return render.ver_contacto(contacto,id,name,f_lastname,s_lastname,email,tel)